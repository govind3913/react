import React from 'react';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import { Link } from 'react-router-dom';

interface Product {
  id: number;
  name: string;
  description: string;
}

const columns: GridColDef[] = [
  { field: 'id', headerName: 'Product ID', width: 150, renderCell: (params) => <Link to={`/product/${params.value}`}>{params.value}</Link> },
  { field: 'name', headerName: 'Name', width: 200 },
  { field: 'description', headerName: 'Description', width: 400 },
];

const mockProducts: Product[] = [
  { id: 1, name: 'Product 1', description: 'Description of Product 1' },
  { id: 2, name: 'Product 2', description: 'Description of Product 2' },
  { id: 3, name: 'Product 3', description: 'Description of Product 3' },
  // Add more mock products as needed
];

const ProductTable: React.FC = () => {
  return (
    <div style={{ height: 400, width: '100%' }}>
      <DataGrid rows={mockProducts} columns={columns}  />
    </div>
  );
};

export default ProductTable;
