import React from 'react';
import { useParams } from 'react-router-dom';

const ProductDetailsPage: React.FC = () => {
  const { id } = useParams<Record<string, string | undefined>>();

  if (!id) {
    return <div>No product ID specified.</div>;
  }

  const productId = parseInt(id);

  // Assuming you fetch product details from API based on the id
  // You need to replace this with actual API call
  const product = {
    id: productId,
    name: `Product ${productId}`,
    description: `Description of Product ${productId}`,
  };

  return (
    <div>
      <h2>Product Details</h2>
      <div>
        <h3>{product.name}</h3>
        <p>{product.description}</p>
      </div>
    </div>
  );
};

export default ProductDetailsPage;
// import React, { useEffect, useState } from 'react';
// import { useParams } from 'react-router-dom';

// interface Product {
//   id: number;
//   name: string;
//   description: string;
// }

// const ProductDetailsPage: React.FC = () => {
//   const { id } = useParams<Record<string, string | undefined>>();
//   const [product, setProduct] = useState<Product | null>(null);

//   useEffect(() => {
//     const fetchProduct = async () => {
//       try {
//         const response = await fetch(`your_api_endpoint/product/${id}`);
//         const data = await response.json();
//         setProduct(data); // Assuming data is an object containing product details
//       } catch (error) {
//         console.error('Error fetching product:', error);
//       }
//     };

//     if (id) {
//       fetchProduct();
//     }
//   }, [id]);

//   if (!id) {
//     return <div>No product ID specified.</div>;
//   }

//   if (!product) {
//     return <div>Loading...</div>;
//   }

//   return (
//     <div>
//       <h2>Product Details</h2>
//       <div>
//         <h3>{product.name}</h3>
//         <p>{product.description}</p>
//       </div>
//     </div>
//   );
// };

// export default ProductDetailsPage;
